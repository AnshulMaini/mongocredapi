package router

import (
	"github.com/AnshulMaini/mongocredapi/controller"
	"github.com/gorilla/mux"
)

func Router() *mux.Router {
	router := mux.NewRouter()
	router.HandleFunc("/mongoapi/booking", controller.CreateBooking).Methods("POST")
	router.HandleFunc("/mongoapi/booking/{id}", controller.MarkAsBooked).Methods("PUT")
	router.HandleFunc("/mongoapi/bookings", controller.GetMyAllEntries).Methods("GET")
	router.HandleFunc("/mongoapi/booking/{id}", controller.DeletAnEntry).Methods("DELETE")
	router.HandleFunc("/mongoapi/deletellbookings", controller.DeleteAllEntries).Methods("DELETE")

	return router
}
