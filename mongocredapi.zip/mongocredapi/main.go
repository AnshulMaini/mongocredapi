package main

import (
	"fmt"
	"log"
	"net/http"

	"github.com/AnshulMaini/mongocredapi/router"
)

func main() {
	fmt.Println("MongoDB")
	r := router.Router()
	fmt.Println("Server is getting started...")
	log.Fatal(http.ListenAndServe(":3000", r))
	fmt.Println("Listening at port 3000...")

}
