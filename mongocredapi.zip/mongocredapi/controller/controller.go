package controller

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/AnshulMaini/mongocredapi/model"
	"github.com/gorilla/mux"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const connection = "mongodb+srv://database:anshul@cluster0.fewwt.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"

const dbName = "Booking"
const colName = "customerlist"

var collection *mongo.Collection

func init() {
	clientOption := options.Client().ApplyURI(connection)
	//connect to mongodb
	client, err := mongo.Connect(context.TODO(), clientOption)
	if err != nil {
		log.Fatal("Error in line 30", err)
	}
	fmt.Println("MongoDB connection success")

	collection = client.Database(dbName).Collection(colName)

	//collection instance
	fmt.Println("Collection instance is ready", collection)

}

func insertOneEntry(booking model.Booking) {
	inserted, err := collection.InsertOne(context.Background(), booking)
	if err != nil {
		log.Fatal("Error in line 44", err)
	}

	fmt.Println("Inserted 1 booking in db with id", inserted.InsertedID)

}

func updateOneEntry(bookingID string) {
	id, err := primitive.ObjectIDFromHex(bookingID)
	if err != nil {
		log.Fatal("Error in line 53", err)

	}
	filter := bson.M{"_id": id}
	update := bson.M{"$set": bson.M{"status": true}}

	result, err := collection.UpdateOne(context.Background(), filter, update)
	if err != nil {
		log.Fatal("Error in line 61", err)
	}
	fmt.Println("modified count: ", result.ModifiedCount)

}

func deleteOneEntry(bookingID string) int64 {
	id, err := primitive.ObjectIDFromHex(bookingID)
	if err != nil {
		log.Fatal("Error in line 70", err)
	}
	filter := bson.M{"_id": id}
	deleteCount, err := collection.DeleteOne(context.Background(), filter)
	if err != nil {
		log.Fatal("Error in line 75", err)
	}
	fmt.Println("Booking got delete with delete count ", deleteCount)
	return deleteCount.DeletedCount

}

func deleteAllEntry() int64 {
	deleteResult, err := collection.DeleteMany(context.Background(), bson.D{{}}, nil)

	if err != nil {
		log.Fatal("Error in line 86", err)
	}

	fmt.Println("NUmber of Bookings delete: ", deleteResult.DeletedCount)
	return deleteResult.DeletedCount
}

func getAllEntry() []primitive.M {
	cur, err := collection.Find(context.Background(), bson.D{{}})
	if err != nil {
		log.Fatal("Error in line 96", err)
	}

	var bookings []primitive.M

	for cur.Next(context.Background()) {
		var booking bson.M
		err := cur.Decode(&booking)
		if err != nil {
			log.Fatal("Error in line 105", err)
		}
		bookings = append(bookings, booking)
	}

	defer cur.Close(context.Background())
	return bookings

}

func GetMyAllEntries(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/x-www-form-urlencode")
	allMovies := getAllEntry()
	json.NewEncoder(w).Encode(allMovies)
}

func CreateBooking(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/x-www-form-urlencode")
	w.Header().Set("Allow-Control-Allow-Methods", "POST")

	var booking model.Booking
	_ = json.NewDecoder(r.Body).Decode(&booking)
	insertOneEntry(booking)
	json.NewEncoder(w).Encode(booking)

}

func MarkAsBooked(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/x-www-form-urlencode")
	w.Header().Set("Allow-Control-Allow-Methods", "PUT")

	param := mux.Vars(r)
	updateOneEntry(param["id"])
	json.NewEncoder(w).Encode("id")
}

func DeletAnEntry(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/x-www-form-urlencode")
	w.Header().Set("Allow-Control-Allow-Methods", "DELETE")

	param := mux.Vars(r)
	count := deleteOneEntry(param["id"])
	json.NewEncoder(w).Encode(count)

}

func DeleteAllEntries(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/x-www-form-urlencode")
	w.Header().Set("Allow-Control-Allow-Methods", "DELETE")

	count := deleteAllEntry()
	json.NewEncoder(w).Encode(count)
}
